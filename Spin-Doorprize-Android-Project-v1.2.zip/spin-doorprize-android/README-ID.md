# Spin Doorprize Android v1.2

Aplikasi undian doorprize offline untuk Android.

## Perubahan v1.2
- Nama aplikasi Android: Spin Doorprize.
- Judul di dalam aplikasi: APLIKASI DOORPRIZE.
- Subjudul: Dibuat oleh.
- Ikon launcher baru berupa kotak hadiah emas dengan latar ungu.
- Nama seluruh peserta ditampilkan pada irisan roda, termasuk saat jumlah peserta lebih dari 18.
- Tetap mempertahankan impor banyak nama, daftar peserta, riwayat, undo, dan penyimpanan lokal.
- Application ID tetap `com.naraeen.arisan.v11` agar v1.2 dapat memperbarui v1.1 tanpa menghapus data aplikasi.

## Build lewat GitHub Actions dari HP
1. Upload ZIP `Spin-Doorprize-Android-Project-v1.2.zip` ke root repository GitHub.
2. Simpan workflow pada `.github/workflows/main.yml` menggunakan YAML yang disertakan di README/chat.
3. Pastikan nama ZIP di YAML sama persis.
4. Commit ke branch `main`.
5. Buka Actions, tunggu build sukses, lalu download artifact `Spin-Doorprize-APK-v1.2`.
6. Install `Spin-Doorprize-v1.2.apk` sebagai update aplikasi sebelumnya.

## Data lokal
Data peserta v1.1 menggunakan key `arisan-spin-v2`; key tersebut dipertahankan agar data yang tersimpan pada perangkat tetap terbaca setelah update. Jangan uninstall versi sebelumnya sebelum memasang versi baru jika ingin mempertahankan data lokal.
