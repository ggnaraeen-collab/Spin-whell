# Arisan Spin — Android APK

Aplikasi undian arisan offline. Nama peserta, riwayat pemenang, dan undo tersimpan lokal di HP melalui localStorage WebView. Tidak meminta izin internet.

## Cara mendapatkan APK lewat HP (tanpa laptop)

1. Ekstrak ZIP ini di HP (gunakan Files / ZArchiver).
2. Buat repository baru di GitHub melalui browser: https://github.com/new
   - Nama: `arisan-spin`
   - Pilih Public atau Private, lalu Create repository.
3. Di repository, pilih **Add file → Upload files**.
4. Upload semua isi folder proyek hasil ekstrak (termasuk folder `.github`, `app`, dan file Gradle). Pastikan `.github/workflows/build-apk.yml` ikut terunggah.
5. Tekan **Commit changes**.
6. Buka tab **Actions** pada repository. Workflow **Build Arisan Spin APK** akan berjalan otomatis. Jika belum, pilih workflow tersebut → **Run workflow**.
7. Setelah status hijau (sukses), buka run terbaru → bagian **Artifacts** → download `Arisan-Spin-APK`.
8. Ekstrak hasil download, lalu buka `app-debug.apk` dan pilih Install. Jika Android meminta izin, izinkan instalasi dari sumber tersebut untuk aplikasi/file manager yang digunakan.

## Fitur
- Tambah dan hapus peserta.
- Spin acak dengan animasi.
- Tampilkan pemenang.
- Keluarkan pemenang dari daftar.
- Batalkan hasil tanpa mengeluarkan peserta.
- Undo perubahan daftar untuk memulihkan kondisi sebelumnya.
- Riwayat pemenang.
- Simpan otomatis lokal dan dapat dipakai offline.

## Catatan
Ini APK debug untuk penggunaan pribadi, bukan rilis Play Store. Jangan hapus data aplikasi jika ingin mempertahankan daftar peserta di HP. Hasil undian dibuat secara acak di perangkat; untuk acara yang membutuhkan audit formal, lakukan undian di hadapan peserta.
