plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.naraeen.arisan"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.naraeen.arisan"
        minSdk = 24
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
