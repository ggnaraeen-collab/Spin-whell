# Arisan Spin Android v1.1

Versi ini menambahkan:
- Impor banyak nama sekaligus dengan tempel daftar satu nama per baris.
- 60 nama dari daftar yang diberikan sudah dimuat otomatis pada instalasi pertama.
- Tampilan UI baru dengan tema midnight-purple dan gold.
- Pencarian nama peserta.
- Deteksi duplikat saat impor.
- Undo satu langkah untuk impor massal, hapus peserta, dan mengeluarkan pemenang.
- Penyimpanan otomatis offline melalui WebView localStorage.

## Build dari HP melalui GitHub Actions
Upload ZIP ini ke repository dengan nama persis `Arisan-Spin-Android-Project-v1.1.zip`.
Pada file `.github/workflows/main.yml`, pastikan langkah ekstrak menggunakan:
`unzip -q Arisan-Spin-Android-Project-v1.1.zip`

Kemudian jalankan workflow. Build menghasilkan:
`arisan-spin-android/app/build/outputs/apk/debug/app-debug.apk`

Artifact yang diunduh dari Actions adalah ZIP berisi APK.

## Penting tentang instalasi
Aplikasi versi ini menggunakan applicationId `com.naraeen.arisan.v11`, sehingga dapat dipasang berdampingan dengan versi 1.0. Jangan hapus versi lama sampai versi 1.1 berhasil dibuka dan daftar nama terlihat.
